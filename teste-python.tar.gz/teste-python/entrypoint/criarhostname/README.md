# criarHostname


Criação e reserva de hostnames para máquinas virtuais, conforme a IN646 para a infraestrutura do Banco do Brasil

## Descrição


Esta API provê uma metologia para criação de reserva de nomes de máquina, exclusivamente para o domínio dispositivos.bb.com.br. Isto se deve ao fato de que toda máquina virtual inicialmente deve ter um nome curto de máquina nesta rede por questões de monitoração.

O ciclo de vida de um Hostname, na forma como construído para esta API, é orientado a um **ID**.
Deve ser solicitada a criação de uma reserva, ao que é retornado este **ID**. Ao ser construído o hostname, este pode ser utilizado através do ID informado.

O diagrama da figura 1 ilustra a sequencia de eventos.

![Sequencia de eventos da reserva de hostname](/modelagem/sequencia-api-reservaHostname.png)*Figura 1 - Reserva de hostnames*

## Ciclo de vida de um hostname

O **ID** gerado pela requisição de reserva é usado para consulta do estado da reserva, cancelamento e utilização da reserva.

A reserva tem um prazo de utilização de 24 horas, após o qual esta será cancelada e nova reserva deverá ser criada.

## Endpoints

Todos os Endpoints mencionados são relativos à URL do serviço.

### Ajuda online

- #### URL

    SERVIDOR/v1/help

- Métodos

    - #### GET

        - Este método retorna esta página

### reservaHostname

- #### URL 

    SERVIDOR/v1/reservaHostname

- Métodos

    - #### POST

        - Este método cria uma reserva, para os dados informados como JSON;

        **Obrigatórios**

        **Headers**

        Content-Type - application/json

        **Mensagem**

        ```
        {
            "ambiente":"",
            "plataforma":"",
            "sistemaOperacional":"",
            "dpr":"",
            "sigla":""
        }
        ```

        **Retorno em sucesso**

        Código HTML: 202 ACCEPTED

        Conteúdo:

        ```
        { \"id\": 369 }
        ```

        **Retornos possíveis em falha**

        Códigos HTML: 400 BAD REQUEST , 500 INTERNAL_SERVER_ERROR

        Conteúdo: Descrição da falha

    - #### GET

        - Este método retorna o estado da reserva

        **Obrigatório**

        **Headers**

        Content-Type - application/json

        **Mensagem**

        ```
        {
            "id":"196"
        }
        ```

        **Retorno em sucesso**

        Código HTML: 200 OK

        Conteúdo:

        ```
        "{\"id\": \"196\", \"hostname\": \"lxl1pdi00\", \"status\": \"reservando\",\"data\": \"2019-01-28 16:30:28\"}"
        ```

        **Retornos possíveis em falha**

        Códigos HTML: 400 BAD REQUEST , 500 INTERNAL_SERVER_ERROR

        Conteúdo: Descrição da falha


    - #### PUT

        - Este método altera o estado da reserva para utilizado

        **Obrigatório**

        **Headers**

        Content-Type - application/json

        **Mensagem**

        ```
        {
            "id":"362"
        }
        ```

        **Retorno em sucesso**

        Código HTML: 200 OK

        Conteúdo:

        ```
        "{\"id\": \"362\", \"hostname\": \"dxl1pdi00093\", \"status\": \"utilizado\",\"data\": \"2019-01-29 11:34:04\"}"
        ```

        **Retornos possíveis em falha**

        Códigos HTML: 400 BAD REQUEST , 500 INTERNAL_SERVER_ERROR

        Conteúdo: Descrição da falha


        Código HTML: 400 BAD REQUEST

        Conteúdo:

        ```
        {
            "FALHA": "id nao pode ser utilizado",
            "dados": {
                        "id": 362
                    },
            "reserva": "{\"id\": \"362\", \"hostname\": \"dxl1pdi00093\", \"status\": \"utilizado\",\"data\": \"2019-01-29 11:34:04\"}"
        }
        ```

    - #### DELETE

       - Este método altera o estado da reserva para cancelado

        **Obrigatório**

        **Headers**

        Content-Type - application/json

        **Mensagem**

        ```
        {
            "id":"362"
        }
        ```

        **Retorno em sucesso**

        Código HTML: 200 OK

        Conteúdo:

        ```
        "{\"id\": \"366\", \"hostname\": \"dxl1pdz00090\", \"status\": \"cancelado\",\"data\": \"2019-01-29 11:35:06\"}"        
        ```

        **Retornos possíveis em falha**

        Códigos HTML: 400 BAD REQUEST , 500 INTERNAL_SERVER_ERROR

        Conteúdo: Descrição da falha


        Código HTML: 400 BAD REQUEST

        Conteúdo:

        ```
        {
            "FALHA": "id nao pode ser cancelado",
            "dados": {
                "id": 366
            },
            "reserva": "{\"id\": \"366\", \"hostname\": \"dxl1pdz00090\", \"status\": \"cancelado\",\"data\": \"2019-01-29 11:35:06\"}"
        }
        ```

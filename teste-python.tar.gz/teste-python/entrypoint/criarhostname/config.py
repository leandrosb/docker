# -*- encoding: utf-8 -*-

# config.py

class Config(object):
    """
    Common configurations
    """
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_POOL_SIZE = 100
    SQLALCHEMY_POOL_RECYCLE = 280

    # Put any configurations here that are common across all environments


class DevelopmentConfig(Config):
    """
    Development configurations
    """
    TIPO = 'DEV'
    DEBUG = True
    SQLALCHEMY_ECHO = True
    HOST_KEYSTONE = 'http://designate.servicos.bb.com.br:5000/v3/auth/tokens'
    HOST_DESIGNATE = 'http://designate.servicos.bb.com.br:9001/v2/zones'
    DESIGNATE_USER = 'pdi00usr'
    DESIGNATE_PASS = '0ckLBMgnxzJpriFoZGTDTH10'
    DNS_ENABLE = True
    MEMCACHE_SERVER = '127.0.0.1'


class ProductionConfig(Config):
    """
    Production configurations
    """
    TIPO = 'PROD'
    DEBUG = False
    HOST_KEYSTONE = 'http://designate.servicos.bb.com.br:5000/v3/auth/tokens'
    HOST_DESIGNATE = 'http://designate.servicos.bb.com.br:9001/v2/zones'
    DESIGNATE_USER = 'pdi00usr'
    DESIGNATE_PASS = '0ckLBMgnxzJpriFoZGTDTH10'
    DNS_ENABLE = True
    MEMCACHE_SERVER = '127.0.0.1'

app_config = {
    'development': DevelopmentConfig,
    'production': ProductionConfig
}

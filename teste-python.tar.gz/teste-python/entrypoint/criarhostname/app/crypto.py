#!/usr/bin/env python3
# -*- encoding: utf-8 -*-


from Crypto import Random
from Crypto.Cipher import AES
import base64
import logging,sys


def pad(data,block_size):
    length = block_size - (len(data) % block_size)
    data += bytes([length])*length
    return data


def unpad(data):
    return data[:-data[-1]]


def encrypt(message, senha, key_size=32):
    try:
        senha = senha[:key_size]
        key = senha + ("w" * (key_size - len(senha)))
        padded_message = pad(message.encode("utf8"),AES.block_size)
        iv = Random.new().read(AES.block_size)
        cipher = AES.new(key.encode("utf8"), AES.MODE_CBC, iv)
        return base64.b64encode(iv + cipher.encrypt(padded_message))
    except:
        logging.error("FALHA! %s ocorreu " % sys.exc_info()[0])
        return None


def decrypt(ciphertext, senha, key_size=32):
    try:
        senha = senha[:key_size]
        key = senha + ("w" * (key_size - len(senha)))
        ctext = base64.b64decode(ciphertext)
        iv = ctext[:AES.block_size]
        crypted = ctext[AES.block_size:]
        cipher = AES.new(key.encode("utf8"), AES.MODE_CBC, iv)
        plaintext = unpad(cipher.decrypt(crypted))
        #logging.warning("enc: %s, dec: %s, senha: %s, t-senha: %s" % (ciphertext,plaintext,key,len(key)))
        return plaintext.decode('utf8')
    except:
        logging.error("FALHA! %s ocorreu " % sys.exc_info()[0])
        return None

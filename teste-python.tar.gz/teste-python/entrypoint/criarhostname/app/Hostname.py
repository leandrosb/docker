# -*- encoding: utf-8 -*-

import time,logging,traceback
from .models import StatusReserva,Reserva,Usuario,Vcenter

class Hostname:

    ambiente: str
    plataforma: str
    sistemaOperacional: str
    dpr: str
    sigla: str
    sequencial: str
    hostname: str
    prefixo: str
    prefixosEmConstrucao = []
    timeout: int = 60


    def __init__(self,ambiente,plataforma,sistemaOperacional,dpr,sigla):
        
        # definições da IN646
        ambientes = ['P','H','D',"L"]
        plataformas = ['S','P','Z','X']
        sistemas = ['L','W','A','S']
        dprs = ['0','1']

        if ambiente.upper() in ambientes:
            self.ambiente = ambiente.lower()
        else:
            raise TypeError("Ambiente informado desconhecido: %s" % ambiente)

        if plataforma.upper() in plataformas:
            self.plataforma = plataforma.lower()
        else:
            raise TypeError("Plataforma informada desconhecida: %s" % plataforma)
        
        if sistemaOperacional.upper() in sistemas:
            self.sistemaOperacional = sistemaOperacional.lower()
        else:
            raise TypeError("Tipo de s.o. informado desconhecido: %s" % sistemaOperacional)

        if dpr in dprs:
            self.dpr = dpr
        else:
            raise TypeError("DPR informado inválido: %s" % dpr)

        if len(sigla) < 3 or len(sigla) > 5:
            raise TypeError("Sigla informada inválida: %s" % sigla)
        else:
            self.sigla = sigla.lower()

        self.sequencial = None
        self.hostname = None
        self.prefixo = ambiente + plataforma + sistemaOperacional + dpr + sigla
        self.prefixo = (self.prefixo + ("0" * (9 - len(self.prefixo)))).lower()

    def __str__(self):
        if self.hostname is not None:
            return "Hostname construído: %s" % self.hostname
        else:
            return "Hostname em construção para a sigla %s" % self.prefixo


    def adicionaPrefixoEmConstrucao(self,reserva):
        reservas = reserva.listaReservasPendentesPorPrefixo(prefixo=self.prefixo,exclui=reserva)
        logging.warning("encontradas reservas " + str(reservas))
        if len(reservas) > 0:
            return False
        if hasattr(type(self),'prefixosEmConstrucao'):
            if self.prefixo not in Hostname.prefixosEmConstrucao:
                Hostname.prefixosEmConstrucao.append(self.prefixo)
                return True
            else:
                return False
        else:
            Hostname.prefixosEmConstrucao.append(self.prefixo)
            return True


    def removePrefixoEmConstrucao(self):
        Hostname.prefixosEmConstrucao.remove(self.prefixo)
        return True

    def criaSequencial(self, vcenters, dns, reserva):
        tempo = 0
        logging.warning("iniciando criaSequencial")

        try:
            if not isinstance(vcenters,list):
                raise TypeError("Vcenters não informados")

            while tempo < self.timeout:
                logging.warning('nova execução do loop, rodada %i de %i' % (tempo,self.timeout))
                if self.adicionaPrefixoEmConstrucao(reserva):
                    logging.warning("conseguiu inserir prefixo para alocação")
                    sequenciais = []
                    if len(vcenters) > 0:
                        for vcenter in vcenters:
                            #logging.warning("listando vms do vcenter " + vcenter.host)
                            vms = vcenter.listaVM(self.prefixo)
                            logging.warning("encontradas as vms " + str(vms))
                            if len(vms) > 0:
                                for vm in vms:
                                    sequenciais.append(int(vm[9:12]))

                    logging.warning("listando vms do dns")
                    registrosDNS = dns.listaVM(self.prefixo)
                    logging.warning("encontrados os registros dns " + str(registrosDNS))
                    if len(registrosDNS) > 0:                    
                        for vm in registrosDNS:
                            sequenciais.append(int(vm[9:12]))

                    logging.warning("listando vms das reservas")
                    reservas = reserva.listaReservasAtivas()
                    logging.warning("encontradas %s reservas: %s" % (len(reservas),str(reservas)))
                    if len(reservas) > 0:
                        for reservado in reservas:
                            sequenciais.append(int(reservado.hostname[9:12]))

                    logging.warning("obtida lista de hostnames em uso, %i no total" % len(sequenciais))
                    todosSequenciais = list(range(0,1000,1))
                    sequenciais_livres = [x for x in todosSequenciais if x not in sequenciais]
                    primeiro_sequencial = str(sequenciais_livres[0])
                    # cria string 000..999
                    self.sequencial = ("0" * (3 - len(primeiro_sequencial))) + primeiro_sequencial
                    self.hostname = self.prefixo + self.sequencial                        
                    logging.warning("hostname construído: " + self.hostname)
                    return True

                else:
                    logging.warning("não conseguiu inserir prefixo para alocação, aguardando 10s")
                    tempo += 1
                    time.sleep(10)

            return False

        except Exception:
            logging.warning("erro: " + traceback.format_exc())


# -*- encoding: utf-8 -*-

from sqlalchemy import Column, ForeignKey, Integer, String, Table, or_, and_, create_engine, Boolean, DateTime
from sqlalchemy.orm import relationship
from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from app import db
from flask import Flask,current_app
import logging
from datetime import datetime
import atexit
from time import clock
from pyVim import connect
import pyVmomi
from pyVmomi import vim
import json,os
import types,ssl,requests
from . import db
from .crypto import encrypt,decrypt,pad,unpad
from sqlalchemy.ext.automap import automap_base
#from sqlalchemy.orm import Session,scoped_session,sessionmaker
#from sqlalchemy import create_engine
#from config import app_config
#from flask_api import FlaskAPI
#from sqlalchemy import create_engine
from flask import Flask, abort, jsonify
#from flask_sqlalchemy_session import flask_scoped_session

'''
def makeSession():
    print("criando sessao")
    print(type(current_app))
    print(type(current_app.config.Session))
    sess = current_app.config.Session()
    print(sess)
    s = flask_scoped_session(current_app.config.Session,current_app)
    print(s)
    print("enviando sessao")
    return s
#
'''
# desabilitando alarmes do ssl quanto a certificados auto-assinados
requests.packages.urllib3.disable_warnings()

def collect_properties(service_instance, view_ref, obj_type, path_set=None,
                       include_mors=False):

    collector = service_instance.content.propertyCollector
    obj_spec = pyVmomi.vmodl.query.PropertyCollector.ObjectSpec()
    obj_spec.obj = view_ref
    obj_spec.skip = True
    traversal_spec = pyVmomi.vmodl.query.PropertyCollector.TraversalSpec()
    traversal_spec.name = 'traverseEntities'
    traversal_spec.path = 'view'
    traversal_spec.skip = False
    traversal_spec.type = view_ref.__class__
    obj_spec.selectSet = [traversal_spec]
    property_spec = pyVmomi.vmodl.query.PropertyCollector.PropertySpec()
    property_spec.type = obj_type

    if not path_set:
        property_spec.all = True

    property_spec.pathSet = path_set
    filter_spec = pyVmomi.vmodl.query.PropertyCollector.FilterSpec()
    filter_spec.objectSet = [obj_spec]
    filter_spec.propSet = [property_spec]
    props = collector.RetrieveContents([filter_spec])

    data = []
    for obj in props:
        properties = {}
        for prop in obj.propSet:
            properties[prop.name] = prop.val

        if include_mors:
            properties['obj'] = obj.obj

        data.append(properties)
    return data


def get_container_view(service_instance, obj_type, container=None):
    if not container:
        container = service_instance.content.rootFolder

    view_ref = service_instance.content.viewManager.CreateContainerView(
        container=container,
        type=obj_type,
        recursive=True
    )
    return view_ref


class Usuario(UserMixin, db.Model):

    # Ensures table will be named in plural and not in singular
    # as is the name of the model
    __tablename__ = 'Usuarios'

    id_usuario = Column(Integer, primary_key=True)
    usuario = Column(String(45), unique=True)
    senha = Column(String(4096))

    def criaSenha(self, password):
        self.senha = generate_password_hash(password)

    def verify_password(self, password):
        return check_password_hash(self.senha, password)

    def __repr__(self):
        return '<Usuario: {}>'.format(self.usuario)


class StatusReserva(db.Model):
    __tablename__ = 'StatusReserva'

    id_status = Column(Integer, primary_key=True)
    status = Column(String(45))

    def __repr__(self):
        return '<StatusReserva: id: %i, status: %s>' % (self.id_status,self.status)

    def __str__(self):
        return '<StatusReserva: id: %i, status: %s>' % (self.id_status,self.status)


class Reserva(db.Model):
    __tablename__ = 'Reservas'

    id_reserva = Column(Integer, primary_key=True)
    hostname = Column(String(12))
    id_status = Column(ForeignKey('StatusReserva.id_status'), nullable=False, index=True)
    data_reserva = Column(DateTime(False))

    status = relationship('StatusReserva', primaryjoin='Reserva.id_status == StatusReserva.id_status', backref='Reserva',lazy='joined')

    def __repr__(self):
        return '{"id": "%s", "hostname": "%s", "status": "%s","data": "%s"}' % (self.id_reserva,self.hostname, self.status.status, self.data_reserva)

    def __str__(self):
        return '{"id": "%s", "hostname": "%s", "status": "%s","data": "%s"}' % (self.id_reserva,self.hostname, self.status.status,self.data_reserva)


    '''
    def __init__(self,session_factory,hostname=None):
        logging.warning("criando objeto reserva para prefixo " + hostname)
        s = session_factory()
        print(s)
        logging.warning(self.status)
        if hostname is not None:
            self.hostname = hostname
        
        s.close()
        logging.warning("finalizado init da reserva")
     '''


    
    def criaReserva(self,hostname):
        #s = makeSession()
        self = Reserva()
        self.hostname = hostname
        self.data_reserva = datetime.now()
        self.status = StatusReserva.query.filter(StatusReserva.status=='reservando').first() # inicial
        db.session.add(self)
        db.session.commit()
        db.session.refresh(self)
        #s.close()
        return self

    '''
    def listaReservasAtivas(self):
        session = makeSession()
        lista = session.query(Reserva).join(StatusReserva, Reserva.id_status==StatusReserva.id_status).filter(or_(
                                                            StatusReserva.status=='reservado',
                                                            StatusReserva.status=='utilizado')).all()
        session.close()
        return lista

    def listaReservasPendentesPorPrefixo(self,prefixo,exclui=None):
        session = makeSession()
        procurado = '%{0}%'.format(prefixo)
        lista = session.query(Reserva).join(StatusReserva, Reserva.id_status==StatusReserva.id_status).filter(and_(
                                                                                            Reserva.hostname.ilike(procurado),
                                                                                            StatusReserva.status=='reservando')).all()

        if isinstance(exclui,Reserva):
            for item in lista:
                if item.id_reserva == exclui.id_reserva:
                    lista.remove(item)

        session.close()
        return lista

    def editaReserva(self,novoStatus=None):
        session = makeSession()
        if novoStatus is not None:
            novoStatusReserva = session.query(StatusReserva).filter(StatusReserva.status == novoStatus).first()
            logging.warning("novo status " + str(novoStatusReserva))
            #db.session.expunge(self.status)
            self.status = novoStatusReserva
        session.commit()
        session.refresh(self)
        session.close()
        return True

    def retornaReserva(self,id):
        print("recebido id " + str(id))
        #session = makeSession()
        #print(session)
        logging.warning("procurando a reserva")
        self = Reserva.query.get(id)
        #session.close()
        return self
    '''

class Vcenter(db.Model):
    __tablename__ = 'Vcenters'

    id_vcenter = Column(Integer, primary_key=True)
    host = Column(String(4096))
    porta = Column(String(45))
    usuario = Column(String(45))
    senha = Column(String(4096))
    habilitado = Column(Boolean)

    def dec_senha(self):
        return decrypt(self.senha,current_app.config['SECRET_KEY'])

    def criaSenha(self, password):
        self.senha = encrypt(self.senha,current_app.config['SECRET_KEY'])

    def __repr__(self):
        return '<Vcenter: {}>'.format(self.host)

    def listaVcenters(self):
        #session = makeSession()
        print(session)
        lista = Vcenter.query.filter(Vcenter.habilitado.is_(True)).all()
        session.close()
        return lista

    def listaVM(self,vmName):
        vm_properties = ["name"]
        vms = []
        service_instance = None
        try:
            service_instance = connect.SmartConnect(host=self.host,
                                                    user=self.usuario,
                                                    pwd=self.dec_senha(),
                                                    port=int(self.porta),
                                                    sslContext=ssl._create_unverified_context())
            atexit.register(connect.Disconnect, service_instance)

        except Exception as error:
            logging.warning(error)
            return None

        if not service_instance:
            logging.warning("sem conexao")
            return None
        else:
            logging.warning("vcenter conectado")
        
        root_folder = service_instance.content.rootFolder
        view = get_container_view(service_instance,
                                        obj_type=[vim.VirtualMachine])
        vm_data = collect_properties(service_instance, view_ref=view,
                                            obj_type=vim.VirtualMachine,
                                            path_set=vm_properties,
                                            include_mors=True)

        logging.warning("obtidos dados do vcenter")

        for vm in vm_data:
            if vmName.lower() in vm["name"].lower():
                vms.append(vm["name"].lower())

        return vms




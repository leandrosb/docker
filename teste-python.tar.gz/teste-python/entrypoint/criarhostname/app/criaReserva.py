#!/usr/bin/env python3
# -*- encoding: utf-8 -*-

import sys,time,logging,json,traceback
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.ext.automap import automap_base
from sqlalchemy.orm import Session,scoped_session,sessionmaker
from sqlalchemy import create_engine
from classes import Base,Reserva,StatusReserva,Vcenter,pad,unpad,encrypt,decrypt,DNS,Hostname
from sqlalchemy.ext.declarative import DeferredReflection
import os


def criaReserva():

    try:

        config = json.loads(sys.argv[1])
        filelog = os.path.join(os.sep,'var','log','criaReserva.log')
        logging.basicConfig(filename=filelog,level=logging.INFO,format='%(asctime)s:%(levelname)s:%(message)s')
        request_engine = create_engine(config['SQLALCHEMY_DATABASE_URI'],isolation_level="READ UNCOMMITTED")
        DeferredReflection.prepare(request_engine)
        Session = sessionmaker(bind=request_engine) 
        session = Session()
        logging.info("recebida configuracao")
        logging.info("vou buscar id_reserva %i" % config['id_reserva'])
        reserva = session.query(Reserva).get(config['id_reserva'])
        logging.info("obtida reserva " + str(reserva))
        hostname = Hostname(config['hostname'][0:1],config['hostname'][1:2],config['hostname'][2:3],config['hostname'][3:4],config['hostname'][4:8])
        logging.info("prefixo recriado: %s " % hostname.prefixo)
        dns = DNS(config)
        logging.info('dns conectado')
        vcenter = Vcenter()
        logging.info('vcenter feito')
        vcenters = vcenter.listaVcenters(session)

        if not isinstance(vcenters,list):
            raise TypeError("Erro no retorno da lista de vms dos vcenters")

        logging.info("vcenters encontrados " + str(vcenters))
        logging.info("criados objetos para reserva de hostname")
    
        if hostname.criaSequencial(vcenters,dns,reserva,config,session):
            reserva.hostname = hostname.hostname
            reserva.editaReserva(session,novoStatus='reservado')
            logging.info("hostname finalizado com sucesso: " + str(reserva))
            session.close()
            return True
            
        else:
            reserva.editaReserva(session,novoStatus='cancelado')
            logging.error("criaSequencial para id_reserva %i finalizado com falha: %s " % (reserva.id_reserva,traceback.format_exc()))
            session.close()
            return True

    except Exception:
        reserva.editaReserva(session,novoStatus='cancelado')
        logging.error("criaSequencial para id_reserva %i finalizado com falha %s" % (reserva.id_reserva,traceback.format_exc()))
        return True
    

# Start program
if __name__ == "__main__":
    criaReserva()
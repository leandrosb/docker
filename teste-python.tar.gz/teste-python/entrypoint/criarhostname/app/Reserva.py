# -*- encoding: utf-8 -*-

import logging
from datetime import datetime
import atexit
from time import clock
from pyVim import connect
import pyVmomi
from pyVmomi import vim
import json,os
import types,ssl,requests
from .crypto import encrypt,decrypt,pad,unpad
from sqlalchemy import Column, ForeignKey, Integer, String, Table, or_, and_, create_engine, Boolean, DateTime
from sqlalchemy.orm import relationship
import sqlalchemy
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

Base = declarative_base()

class StatusReserva(Base):
    __tablename__ = 'StatusReserva'

    id_status = Column(Integer, primary_key=True)
    status = Column(String(45))
    Session = None

    def conecta(self,db_engine):
        self.Session = sessionmaker(bind=db_engine)    

    def __repr__(self):
        return '<StatusReserva: id: %i, status: %s>' % (self.id_status,self.status)

    def __str__(self):
        return '<StatusReserva: id: %i, status: %s>' % (self.id_status,self.status)


class Reserva(Base):
    __tablename__ = 'Reservas'

    id_reserva = Column(Integer, primary_key=True)
    hostname = Column(String(12))
    id_status = Column(ForeignKey('StatusReserva.id_status'), nullable=False, index=True)
    data_reserva = Column(DateTime(False))
    Session = None

    status = relationship('StatusReserva', primaryjoin='Reserva.id_status == StatusReserva.id_status', backref='Reserva',lazy='joined')

    def __repr__(self):
        return '{"id": "%s", "hostname": "%s", "status": "%s","data": "%s"}' % (self.id_reserva,self.hostname, self.status.status, self.data_reserva)


    def __str__(self):
        return '{"id": "%s", "hostname": "%s", "status": "%s","data": "%s"}' % (self.id_reserva,self.hostname, self.status.status,self.data_reserva)


    def __init__(self):
        logging.warning("criando objeto reserva")


    def conecta(self,db_engine):
        logging.warning("vai criar sessao")
        self.Session = sessionmaker(bind=db_engine)    
        logging.warning(self.Session)


    def criaReserva(self,hostname):
        #s = makeSession()
        self = Reserva()
        self.hostname = hostname
        self.data_reserva = datetime.now()
        self.status = self.query(StatusReserva).filter(StatusReserva.status=='reservando').first() # inicial
        self.Session.add(self)
        self.Session.commit()
        self.Session.refresh(self)
        return self

    
    def listaReservasAtivas(self):
        self.Session.refresh(self)
        lista = self.Session.query(Reserva).join(StatusReserva, Reserva.id_status==StatusReserva.id_status).filter(or_(
                                                            StatusReserva.status=='reservado',
                                                            StatusReserva.status=='utilizado')).all()
        return lista

    def listaReservasPendentesPorPrefixo(self,prefixo,exclui=None):
        self.Session.refresh(self)
        procurado = '%{0}%'.format(prefixo)
        lista = session.query(Reserva).join(StatusReserva, Reserva.id_status==StatusReserva.id_status).filter(and_(
                                                                                            Reserva.hostname.ilike(procurado),
                                                                                            StatusReserva.status=='reservando')).all()

        if isinstance(exclui,Reserva):
            for item in lista:
                if item.id_reserva == exclui.id_reserva:
                    lista.remove(item)

        session.close()
        return lista

    def editaReserva(self,novoStatus=None):
        self.Session.refresh(self)
        if novoStatus is not None:
            novoStatusReserva = self.Session.query(StatusReserva).filter(StatusReserva.status == novoStatus).first()
            logging.warning("novo status " + str(novoStatusReserva))
            #db.session.expunge(self.status)
            self.status = novoStatusReserva
        self.Session.commit()
        self.Session.refresh(self)
        return True
    '''
    def retornaReserva(self,id):
        print("recebido id " + str(id))
        #session = makeSession()
        #print(session)
        logging.warning("procurando a reserva")
        self = Reserva.query.get(id)
        #session.close()
        return self
    '''
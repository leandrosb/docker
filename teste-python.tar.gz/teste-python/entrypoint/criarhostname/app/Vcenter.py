# -*- encoding: utf-8 -*-


import logging
from datetime import datetime
import atexit
from time import clock
from pyVim import connect
import pyVmomi
from pyVmomi import vim
import json,os
import types,ssl,requests
from .crypto import encrypt,decrypt,pad,unpad
from sqlalchemy import Column, ForeignKey, Integer, String, Table, or_, and_, create_engine, Boolean, DateTime
from sqlalchemy.orm import relationship
import sqlalchemy
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

Base = declarative_base()

class Vcenter(Base):
    __tablename__ = 'Vcenters'

    id_vcenter = Column(Integer, primary_key=True)
    host = Column(String(4096))
    porta = Column(String(45))
    usuario = Column(String(45))
    senha = Column(String(4096))
    habilitado = Column(Boolean)
    Session = None

    def conecta(self,db_engine):
        self.Session = sessionmaker(bind=db_engine)


    def dec_senha(self,password):
        return decrypt(self.senha, password)

    def criaSenha(self, password):
        self.senha = encrypt(self.senha, password)

    def __repr__(self):
        return '<Vcenter: {}>'.format(self.host)

    def listaVcenters(self):
        session = self.Session()
        #print(session)
        lista = session.query(Vcenter).filter(Vcenter.habilitado.is_(True)).all()
        session.close()
        return lista

    def listaVM(self,vmName):
        vm_properties = ["name"]
        vms = []
        service_instance = None
        try:
            service_instance = connect.SmartConnect(host=self.host,
                                                    user=self.usuario,
                                                    pwd=self.dec_senha(),
                                                    port=int(self.porta),
                                                    sslContext=ssl._create_unverified_context())
            atexit.register(connect.Disconnect, service_instance)

        except Exception as error:
            logging.warning(error)
            return None

        if not service_instance:
            logging.warning("sem conexao")
            return None
        else:
            logging.warning("vcenter conectado")
        
        root_folder = service_instance.content.rootFolder
        view = get_container_view(service_instance,
                                        obj_type=[vim.VirtualMachine])
        vm_data = collect_properties(service_instance, view_ref=view,
                                            obj_type=vim.VirtualMachine,
                                            path_set=vm_properties,
                                            include_mors=True)

        logging.warning("obtidos dados do vcenter")

        for vm in vm_data:
            if vmName.lower() in vm["name"].lower():
                vms.append(vm["name"].lower())

        return vms



requests.packages.urllib3.disable_warnings()

def collect_properties(service_instance, view_ref, obj_type, path_set=None,
                       include_mors=False):

    collector = service_instance.content.propertyCollector
    obj_spec = pyVmomi.vmodl.query.PropertyCollector.ObjectSpec()
    obj_spec.obj = view_ref
    obj_spec.skip = True
    traversal_spec = pyVmomi.vmodl.query.PropertyCollector.TraversalSpec()
    traversal_spec.name = 'traverseEntities'
    traversal_spec.path = 'view'
    traversal_spec.skip = False
    traversal_spec.type = view_ref.__class__
    obj_spec.selectSet = [traversal_spec]
    property_spec = pyVmomi.vmodl.query.PropertyCollector.PropertySpec()
    property_spec.type = obj_type

    if not path_set:
        property_spec.all = True

    property_spec.pathSet = path_set
    filter_spec = pyVmomi.vmodl.query.PropertyCollector.FilterSpec()
    filter_spec.objectSet = [obj_spec]
    filter_spec.propSet = [property_spec]
    props = collector.RetrieveContents([filter_spec])

    data = []
    for obj in props:
        properties = {}
        for prop in obj.propSet:
            properties[prop.name] = prop.val

        if include_mors:
            properties['obj'] = obj.obj

        data.append(properties)
    return data


def get_container_view(service_instance, obj_type, container=None):
    if not container:
        container = service_instance.content.rootFolder

    view_ref = service_instance.content.viewManager.CreateContainerView(
        container=container,
        type=obj_type,
        recursive=True
    )
    return view_ref

# -*- encoding: utf-8 -*-

import sys,time
from flask import current_app
import requests,logging,traceback

class DNS:

    hostKeystone: str
    hostDesignate: str
    usuario: str
    senha: str
    habilitado: bool
    token: str
    loginEndpoint: str 
    domain: str = 'dispositivos.bb.com.br'
    idZona: str


    def __init__(self):

        logging.warning("dns inicializando")

        config = current_app.config
        logging.warning("configuração obtida")
        #logging.warning(config)

        self.hostKeystone = config['HOST_KEYSTONE']
        self.hostDesignate = config['HOST_DESIGNATE']
        self.usuario = config['DESIGNATE_USER']
        self.senha = config['DESIGNATE_PASS']
        self.habilitado = config['DNS_ENABLE']

        logging.warning("dns inicializado")



    def obtemToken(self):

        data = '''{ "auth": {
    "identity": {
      "methods": ["password"],
      "password": {
        "user": {
          "name": "pdi00usr",
          "domain": { "id": "default" },
          "password": "0ckLBMgnxzJpriFoZGTDTH10"
        }
      }
    },
    "scope": {
      "project": {
        "name": "dns_service",
        "domain": { "id": "default" }
      }
    }
  }
}'''

        headers = {'Content-type': 'application/json'}

        try:
            r = requests.post(self.hostKeystone,data=data,verify=False,headers=headers)

            if r.headers['X-Subject-Token'] is not None:
                self.token = r.headers['X-Subject-Token']
                logging.warning("token obtido")
                return True
            else:
                logging.warning(r.text)
                logging.warning(r.headers)
                raise SystemError(r)
        except Exception as error:
            logging.warning("falha obtendo token " + traceback.format_exc())
            return False


    def obtemZona(self):
        self.obtemToken()
        try:
            params = {'name':(self.domain + ".")}
            headers = {'Content-type': 'application/json', 'x-auth-token':self.token}
            r = requests.get(self.hostDesignate,params=params,verify=False,headers=headers)
            zonas = r.json()
            #logging.warning(zonas)
            self.idZona = zonas['zones'][0]['id']
            logging.warning("zona obtida: " + self.idZona)
            return True
        except Exception as error:
            logging.warning("falha obtendo zona " + traceback.format_exc())
            return False


    def listaVM(self,prefixo):
        self.obtemZona()
        vms = []
        try:
            params = {'name':(prefixo + "*")}
            headers = {'Content-type': 'application/json', 'x-auth-token':self.token}
            r = requests.get(self.hostDesignate + "/" + self.idZona + "/recordsets" ,params=params,verify=False,headers=headers)
            registros = r.json()
            for registro in registros['recordsets']:
                #logging.warning(registro)
                nome = registro['name'].split(".")[0]
                vms.append(nome)
            #logging.warning("registros dns obtidos " + str(vms))
            return vms
        except Exception as error:
            logging.warning("falha obtendo registros " + traceback.format_exc())
            return False




# -*- encoding: utf-8 -*-

from flask_api import FlaskAPI, status, exceptions
from flask import Blueprint, current_app, request, jsonify,send_from_directory
from . import context
from .. import db
import subprocess
import traceback
import json
import numbers
import sys
import os
import logging
import time
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.ext.automap import automap_base
from sqlalchemy.orm import Session,scoped_session,sessionmaker
from sqlalchemy import create_engine
from ..classes import Base,Reserva,StatusReserva,Vcenter,Hostname,DNS,unpad,pad,encrypt,decrypt
from sqlalchemy.ext.declarative import DeferredReflection
import markdown

filelog = os.path.join(os.sep,'var','log','criaReserva.log')
logging.basicConfig(filename=filelog,level=logging.INFO,format='%(asctime)s:%(levelname)s:%(message)s')


@context.context_processor
def inject_conf():
    return dict(config=current_app.config)


@context.route('/modelagem/<path:path>')
def send_images(path):
    root = current_app.root_path
    filename, file_extension = os.path.splitext(path)
    if file_extension == '.png':
        return send_from_directory(os.path.join(root,'../modelagem'),path)
    else:
        return "NEGADO", status.HTTP_403_FORBIDDEN


@context.route('/v1/help')
def homepage():
    file = open("README.md","r")
    texto = file.read()
    html = markdown.markdown(texto)
    file.close()
    return "<html><body>" + html + "</body></html>", status.HTTP_200_OK


@context.route('/v1/reservaHostname', methods=['GET','POST','PUT','DELETE'])
def reservaHostname():

    request_engine = create_engine(current_app.config['SQLALCHEMY_DATABASE_URI'],isolation_level="READ UNCOMMITTED")
    DeferredReflection.prepare(request_engine)
    Session = sessionmaker(bind=request_engine) 
    session = Session()

    ##### - consulta a reserva por id
    if request.method == 'GET':
        id = int(request.data.get('id',''))

        if id is not None:
            logging.info("consulta reserva - reserva para id " + str(id))
            reserva = Reserva()
            reserva = session.query(Reserva).get(id)
            if reserva is not None:
                return jsonify(str(reserva))
            else:
                return {'FALHA':'id nao encontrado', 'dados':request.data}, status.HTTP_404_NOT_FOUND
        else:
            return {'FALHA':'id nao informado', 'dados':request.data}, status.HTTP_400_BAD_REQUEST

    ##### cria uma reserva
    elif request.method == 'POST':

        try:
            hostname = Hostname(ambiente=request.data['ambiente'],
                                plataforma=request.data['plataforma'],
                                sistemaOperacional=request.data['sistemaOperacional'],
                                dpr=request.data['dpr'],
                                sigla=request.data['sigla'])

            reserva = Reserva()
            reserva = reserva.criaReserva(hostname.prefixo,session)
            config = {}
            config['hostname'] = hostname.prefixo
            config['MEMCACHE_SERVER'] = current_app.config['MEMCACHE_SERVER']
            config['TIPO'] = current_app.config['TIPO']
            config['HOST_KEYSTONE'] = current_app.config['HOST_KEYSTONE']
            config['HOST_DESIGNATE'] = current_app.config['HOST_DESIGNATE']
            config['DESIGNATE_USER'] = current_app.config['DESIGNATE_USER']
            config['DESIGNATE_PASS'] = current_app.config['DESIGNATE_PASS']
            config['DNS_ENABLE'] = current_app.config['DNS_ENABLE']
            config['SQLALCHEMY_DATABASE_URI'] = current_app.config['SQLALCHEMY_DATABASE_URI']
            config['SECRET_KEY'] = current_app.config['SECRET_KEY']
            config['id_reserva'] = reserva.id_reserva
            filename = os.path.join(current_app.root_path, 'criaReserva.py')
            p_args = json.dumps(config)            
            p_id = subprocess.Popen(['python3',filename,p_args]).pid
            logging.info("criado processo %i para criar hostname da reserva %i prefixo %s" % (p_id,reserva.id_reserva,hostname.prefixo))
            return {'id':reserva.id_reserva}, status.HTTP_202_ACCEPTED

        except TypeError as error:
            session.close()
            logging.error(traceback.format_exc())
            return error, status.HTTP_400_BAD_REQUEST

        except Exception as error:
            session.close()
            logging.error(traceback.format_exc())
            return error, status.HTTP_500_INTERNAL_SERVER_ERROR


    ##### usa a reserva
    elif request.method == 'PUT':
        id = int(request.data.get('id',''))

        if id is not None:
            reserva = Reserva()
            reserva = session.query(Reserva).get(id)
            if reserva is not None:
                if (reserva.status.status == 'reservado'):
                    logging.info("usar reserva - encontrada reserva " + str(reserva) + ", marcando como utilizada")
                    reserva.editaReserva(session,novoStatus='utilizado')
                    session.close()
                    return jsonify(str(reserva))
                else:
                    session.close()
                    return {'FALHA':'id nao pode ser utilizado', 'dados':request.data, 'reserva':str(reserva)}, status.HTTP_400_BAD_REQUEST        
            else:
                session.close()
                return {'FALHA':'id nao encontrado', 'dados':request.data}, status.HTTP_404_NOT_FOUND
        else:
            session.close()
            return {'FALHA':'id nao informado', 'dados':request.data}, status.HTTP_400_BAD_REQUEST


    ##### cancela a reserva
    elif request.method == 'DELETE':
        id = int(request.data.get('id',''))

        if id is not None:
            reserva = Reserva()
            reserva = session.query(Reserva).get(id)
            if reserva is not None:
                if reserva.status.status in ['reservado','reservando']:
                    logging.info("cancela reserva - encontrada reserva " + str(reserva) + ", marcando como cancelada")
                    reserva.editaReserva(session,novoStatus='cancelado')
                    session.close()
                    return jsonify(str(reserva))
                else:
                    session.close()
                    return {'FALHA':'id nao pode ser cancelado', 'dados':request.data,'reserva':str(reserva)}, status.HTTP_400_BAD_REQUEST
            else:
                session.close()
                return {'FALHA':'id nao encontrado', 'dados':request.data}, status.HTTP_404_NOT_FOUND
        else:
            session.close()
            return {'FALHA':'id nao informado', 'dados':request.data}, status.HTTP_400_BAD_REQUEST

    else:
        session.close()
        return {'FALHA':("Operacao %s invalida" % request.method), 'dados': request.data}, status.HTTP_400_BAD_REQUEST


# -*- encoding: utf-8 -*-


from flask import Blueprint

context = Blueprint('/v1', __name__)

from . import contexto_v1


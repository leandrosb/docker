# -*- encoding: utf-8 -*-


import logging
from datetime import datetime
import atexit
from time import clock
from pyVim import connect
import pyVmomi
from pyVmomi import vim
import json,os
import types,ssl,requests
from sqlalchemy import Column, ForeignKey, Integer, String, Table, or_, and_, create_engine, Boolean, DateTime
from sqlalchemy.orm import relationship
import sqlalchemy
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.ext.automap import automap_base
from sqlalchemy.ext.declarative import DeferredReflection
from sqlalchemy.orm import sessionmaker
from Crypto import Random
from Crypto.Cipher import AES
import base64
import traceback
import time


Base = declarative_base()

requests.packages.urllib3.disable_warnings()

def collect_properties(service_instance, view_ref, obj_type, path_set=None,
                       include_mors=False):

    collector = service_instance.content.propertyCollector
    obj_spec = pyVmomi.vmodl.query.PropertyCollector.ObjectSpec()
    obj_spec.obj = view_ref
    obj_spec.skip = True
    traversal_spec = pyVmomi.vmodl.query.PropertyCollector.TraversalSpec()
    traversal_spec.name = 'traverseEntities'
    traversal_spec.path = 'view'
    traversal_spec.skip = False
    traversal_spec.type = view_ref.__class__
    obj_spec.selectSet = [traversal_spec]
    property_spec = pyVmomi.vmodl.query.PropertyCollector.PropertySpec()
    property_spec.type = obj_type

    if not path_set:
        property_spec.all = True

    property_spec.pathSet = path_set
    filter_spec = pyVmomi.vmodl.query.PropertyCollector.FilterSpec()
    filter_spec.objectSet = [obj_spec]
    filter_spec.propSet = [property_spec]
    props = collector.RetrieveContents([filter_spec])

    data = []
    for obj in props:
        properties = {}
        for prop in obj.propSet:
            properties[prop.name] = prop.val

        if include_mors:
            properties['obj'] = obj.obj

        data.append(properties)
    return data


def get_container_view(service_instance, obj_type, container=None):
    if not container:
        container = service_instance.content.rootFolder

    view_ref = service_instance.content.viewManager.CreateContainerView(
        container=container,
        type=obj_type,
        recursive=True
    )
    return view_ref


def pad(data,block_size):
    length = block_size - (len(data) % block_size)
    data += bytes([length])*length
    return data


def unpad(data):
    return data[:-data[-1]]


def encrypt(message, senha, key_size=32):
    try:
        senha = senha[:key_size]
        key = senha + ("w" * (key_size - len(senha)))
        padded_message = pad(message.encode("utf8"),AES.block_size)
        iv = Random.new().read(AES.block_size)
        cipher = AES.new(key.encode("utf8"), AES.MODE_CBC, iv)
        return base64.b64encode(iv + cipher.encrypt(padded_message))
    except:
        logging.error("FALHA! %s ocorreu " % sys.exc_info()[0])
        return None


def decrypt(ciphertext, senha, key_size=32):
    try:
        senha = senha[:key_size]
        key = senha + ("w" * (key_size - len(senha)))
        ctext = base64.b64decode(ciphertext)
        iv = ctext[:AES.block_size]
        crypted = ctext[AES.block_size:]
        cipher = AES.new(key.encode("utf8"), AES.MODE_CBC, iv)
        plaintext = unpad(cipher.decrypt(crypted))
        return plaintext.decode('utf8')
    except:
        logging.error("FALHA! %s ocorreu " % sys.exc_info()[0])
        return None


class Vcenter(DeferredReflection,Base):
    __tablename__ = 'Vcenters'

    id_vcenter = Column(Integer, primary_key=True)
    host = Column(String(4096))
    porta = Column(String(45))
    usuario = Column(String(45))
    senha = Column(String(4096))
    habilitado = Column(Boolean)
    Session = None

    def conecta(self,db_engine):
        session = sessionmaker(bind=db_engine)
        self.Session = session()
        logging.warning("criada sessao para vcenter")
        logging.warning(self.Session)


    def dec_senha(self,password):
        return decrypt(self.senha, password)

    def criaSenha(self, password):
        self.senha = encrypt(self.senha, password)

    def __repr__(self):
        return '<Vcenter: {}>'.format(self.host)

    def listaVcenters(self,session):
        lista = session.query(Vcenter).filter(Vcenter.habilitado.is_(True)).all()
        return lista

    def listaVM(self,vmName,senha):
        vm_properties = ["name"]
        vms = []
        service_instance = None
        try:
            service_instance = connect.SmartConnect(host=self.host,
                                                    user=self.usuario,
                                                    pwd=self.dec_senha(senha),
                                                    port=int(self.porta),
                                                    sslContext=ssl._create_unverified_context())
            atexit.register(connect.Disconnect, service_instance)

        except Exception as error:
            logging.warning(error)
            return None

        if not service_instance:
            logging.warning("sem conexao")
            return None
        else:
            logging.warning("vcenter conectado")
        
        view = get_container_view(service_instance,
                                        obj_type=[vim.VirtualMachine])
        vm_data = collect_properties(service_instance, view_ref=view,
                                            obj_type=vim.VirtualMachine,
                                            path_set=vm_properties,
                                            include_mors=True)

        logging.warning("obtidos dados do vcenter")

        for vm in vm_data:
            if vmName.lower() in vm["name"].lower():
                vms.append(vm["name"].lower())

        return vms

class StatusReserva(DeferredReflection,Base):
    __tablename__ = 'StatusReserva'

    id_status = Column(Integer, primary_key=True)
    status = Column(String(45))   

    def __repr__(self):
        return '<StatusReserva: id: %i, status: %s>' % (self.id_status,self.status)

    def __str__(self):
        return '<StatusReserva: id: %i, status: %s>' % (self.id_status,self.status)


class Reserva(DeferredReflection,Base):
    __tablename__ = 'Reservas'

    id_reserva = Column(Integer, primary_key=True)
    hostname = Column(String(12))
    id_status = Column(ForeignKey('StatusReserva.id_status'), nullable=False, index=True)
    data_reserva = Column(DateTime(False))
    Session = None

    status = relationship('StatusReserva', primaryjoin='Reserva.id_status == StatusReserva.id_status', backref='Reserva',lazy='joined')

    def __repr__(self):
        return '{"id": "%s", "hostname": "%s", "status": "%s","data": "%s"}' % (self.id_reserva,self.hostname, self.status.status, self.data_reserva)


    def __str__(self):
        return '{"id": "%s", "hostname": "%s", "status": "%s","data": "%s"}' % (self.id_reserva,self.hostname, self.status.status,self.data_reserva)


    def criaReserva(self,hostname,session):
        self.hostname = hostname
        self.data_reserva = datetime.now()
        self.status = session.query(StatusReserva).filter(StatusReserva.status=='reservando').first() # inicial
        session.add(self)
        session.commit()
        session.refresh(self)
        return self

    
    def listaReservasAtivas(self,session):
        session.flush()
        lista = session.query(Reserva).join(StatusReserva, Reserva.id_status==StatusReserva.id_status).filter(or_(
                                                            StatusReserva.status=='reservado',
                                                            StatusReserva.status=='utilizado')).all()
        return lista

    
    def listaReservasPendentesPorPrefixo(self,prefixo,session,exclui=None):
        session.flush()
        procurado = '%{0}%'.format(prefixo)
        lista = session.query(Reserva).join(StatusReserva, Reserva.id_status==StatusReserva.id_status).filter(and_(
                                                                                            Reserva.hostname.ilike(procurado),
                                                                                            StatusReserva.status=='reservando')).all()

        if isinstance(exclui,Reserva):
            for item in lista:
                if item.id_reserva == exclui.id_reserva:
                    lista.remove(item)

        return lista

    def editaReserva(self,session,novoStatus=None):
        if novoStatus is not None:
            if self.status.status is not 'cancelado':
                logging.warning("status da reserva " + self.status.status)
                if novoStatus is not None:
                    logging.warning(self.Session)
                    novoStatusReserva = session.query(StatusReserva).filter(StatusReserva.status == novoStatus).first()
                    logging.warning("editando novo status para reserva: %s " % novoStatusReserva.status)
                    self.status = novoStatusReserva
                    session.commit()
                    session.refresh(self)
                return True
            else:
                logging.warning("reserva cancelada nao pode mais ser editada")
                return False


class DNS:

    hostKeystone: str
    hostDesignate: str
    usuario: str
    senha: str
    habilitado: bool
    token: str
    loginEndpoint: str 
    domain: str = 'dispositivos.bb.com.br'
    idZona: str


    def __init__(self,dns_config):

        logging.warning("dns inicializando")
        self.hostKeystone = dns_config['HOST_KEYSTONE']
        self.hostDesignate = dns_config['HOST_DESIGNATE']
        self.usuario = dns_config['DESIGNATE_USER']
        self.senha = dns_config['DESIGNATE_PASS']
        self.habilitado = dns_config['DNS_ENABLE']
        logging.warning("dns inicializado")


    def obtemToken(self):

        data = '''{ "auth": {
    "identity": {
      "methods": ["password"],
      "password": {
        "user": {
          "name": "pdi00usr",
          "domain": { "id": "default" },
          "password": "0ckLBMgnxzJpriFoZGTDTH10"
        }
      }
    },
    "scope": {
      "project": {
        "name": "dns_service",
        "domain": { "id": "default" }
      }
    }
  }
}'''

        headers = {'Content-type': 'application/json'}

        try:
            r = requests.post(self.hostKeystone,data=data,verify=False,headers=headers)

            if r.headers['X-Subject-Token'] is not None:
                self.token = r.headers['X-Subject-Token']
                logging.warning("token obtido")
                return True
            else:
                logging.warning(r.text)
                logging.warning(r.headers)
                raise SystemError(r)
        except Exception:
            logging.warning("falha obtendo token " + traceback.format_exc())
            return False


    def obtemZona(self):
        self.obtemToken()
        try:
            params = {'name':(self.domain + ".")}
            headers = {'Content-type': 'application/json', 'x-auth-token':self.token}
            r = requests.get(self.hostDesignate,params=params,verify=False,headers=headers)
            zonas = r.json()
            self.idZona = zonas['zones'][0]['id']
            logging.warning("zona obtida: " + self.idZona)
            return True
        except Exception:
            logging.warning("falha obtendo zona " + traceback.format_exc())
            return False


    def listaVM(self,prefixo):
        self.obtemZona()
        vms = []
        try:
            params = {'name':(prefixo + "*")}
            headers = {'Content-type': 'application/json', 'x-auth-token':self.token}
            r = requests.get(self.hostDesignate + "/" + self.idZona + "/recordsets" ,params=params,verify=False,headers=headers)
            registros = r.json()
            for registro in registros['recordsets']:
                nome = registro['name'].split(".")[0]
                vms.append(nome)
            return vms
        except Exception:
            logging.warning("falha obtendo registros " + traceback.format_exc())
            return False


class Hostname:

    ambiente: str
    plataforma: str
    sistemaOperacional: str
    dpr: str
    sigla: str
    sequencial: str
    hostname: str
    prefixo: str
    prefixosEmConstrucao = []
    timeout: int = 60
    memc = None

    def __init__(self,ambiente,plataforma,sistemaOperacional,dpr,sigla):
        
        # definições da IN646
        ambientes = ['P','H','D',"L"]
        plataformas = ['S','P','Z','X']
        sistemas = ['L','W','A','S']
        dprs = ['0','1']

        if ambiente.upper() in ambientes:
            self.ambiente = ambiente.lower()
        else:
            raise TypeError("Ambiente informado desconhecido: %s" % ambiente)

        if plataforma.upper() in plataformas:
            self.plataforma = plataforma.lower()
        else:
            raise TypeError("Plataforma informada desconhecida: %s" % plataforma)
        
        if sistemaOperacional.upper() in sistemas:
            self.sistemaOperacional = sistemaOperacional.lower()
        else:
            raise TypeError("Tipo de s.o. informado desconhecido: %s" % sistemaOperacional)

        if dpr in dprs:
            self.dpr = dpr
        else:
            raise TypeError("DPR informado inválido: %s" % dpr)

        if len(sigla) < 3 or len(sigla) > 5:
            raise TypeError("Sigla informada inválida: %s" % sigla)
        else:
            self.sigla = sigla.lower()

        self.sequencial = None
        self.hostname = None
        self.prefixo = ambiente + plataforma + sistemaOperacional + dpr + sigla
        self.prefixo = (self.prefixo + ("0" * (9 - len(self.prefixo)))).lower()

    def __str__(self):
        if self.hostname is not None:
            return "Hostname construído: %s" % self.hostname
        else:
            return "Hostname em construção para a sigla %s" % self.prefixo


    def adicionaPrefixoEmConstrucao(self,reserva,config,session):
        reservas = reserva.listaReservasPendentesPorPrefixo(self.prefixo,session,exclui=reserva)
        if len(reservas) > 0:
            ids_reserva = []
            for reserva_bd in reservas:
                ids_reserva.append(reserva_bd.id_reserva)

            ids_reserva.sort()
            logging.warning("reserva %i: ids em reserva no bd: %s" % (reserva.id_reserva,str(ids_reserva)))

            if ids_reserva[0] < reserva.id_reserva:
                logging.warning("existe reserva em andamento %i com prioridade para o prefixo %s, aguardando para id %i" % (ids_reserva[0],self.prefixo,reserva.id_reserva))
                return False
            else:
                logging.warning("reserva em andamento %i tem prioridade para o prefixo %s" % (reserva.id_reserva,self.prefixo))
                return True

        else:
            logging.warning("prefixo %s sem reservas em andamento em banco de dados, verificando memcache" % self.prefixo)
            return True

        '''
        if self.memc is None:
            try:
                self.memc = Client((config['MEMCACHE_SERVER'],11211),
                                    serializer=serde.get_python_memcache_serializer(pickle_version=2),
                                    deserializer=serde.python_memcache_deserializer,
                                    timeout=15,
                                    connect_timeout=15,
                                    no_delay=True,
                                    ignore_exc=True)
                logging.warning("criei conexao ao memcache")

            except Exception:
                logging.warning('falha: ' + traceback.format_exc())
                return False

        existente = self.memc.get(self.prefixo, default=None)
        logging.warning("obtida resposta memcache: " + str(existente))
        if existente is None:            
            self.memc.set(self.prefixo, {'id_reserva':reserva.id_reserva, 'data':reserva.data_reserva},expire=36,noreply=False)
            logging.warning("prefixo adicionado ao memcache")
            return True
        else:
            logging.warning("prefixo %s existe em memcache, abortando" % str(existente))
            # maximo de 1 hora para construir hostname, 
            # ou remove tentativa anterior e finaliza processos pendentes anteriores
            # construir
            return False

        # memcached key: prefixo values: id_reserva: reserva.id_reserva, data: reserva.data_reserva
        '''


    def removePrefixoEmConstrucao(self,reserva):
        if self.memc is not None:
            self.memc.delete(self.prefixo,noreply=False)
            logging.warning("reserva %i: removido prefixo %s do memcache" %  (reserva.id_reserva,self.prefixo))
        return True


    def criaSequencial(self, vcenters, dns, reserva,config,session):
        tempo = 0
        logging.warning("iniciando criaSequencial")
        logging.warning("recebidos:")
        logging.warning(str(reserva))
        logging.warning(str(dns))
        logging.warning(str(vcenters))
        try:
            if not isinstance(vcenters,list):
                raise TypeError("Vcenters não informados")

            while tempo < self.timeout:
                logging.warning('nova execução do loop, rodada %i de %i' % (tempo,self.timeout))
                if self.adicionaPrefixoEmConstrucao(reserva,config,session):
                    logging.warning("conseguiu inserir prefixo para alocação em memcache")
                    sequenciais = []
                    if len(vcenters) > 0:
                        for vcenter in vcenters:
                            vms = vcenter.listaVM(self.prefixo,config['SECRET_KEY'])
                            logging.warning("encontradas %i vms em vcenters " % len(vms))
                            if len(vms) > 0:
                                for vm in vms:
                                    sequenciais.append(int(vm[9:12]))

                    logging.warning("listando vms do dns")
                    registrosDNS = dns.listaVM(self.prefixo)
                    logging.warning("encontrados %i os registros dns " % len(registrosDNS))
                    if len(registrosDNS) > 0:                    
                        for vm in registrosDNS:
                            sequenciais.append(int(vm[9:12]))

                    logging.warning("listando vms das reservas")
                    reservas = reserva.listaReservasAtivas(session)
                    logging.warning("encontradas %s reservas ativas" % (len(reservas)))
                    if len(reservas) > 0:
                        for reservado in reservas:
                            sequenciais.append(int(reservado.hostname[9:12]))

                    logging.warning("obtida lista de hostnames em uso, %i no total" % len(sequenciais))
                    todosSequenciais = list(range(1,1000,1))
                    sequenciais_livres = [x for x in todosSequenciais if x not in sequenciais]
                    primeiro_sequencial = str(sequenciais_livres[0])
                    self.sequencial = ("0" * (3 - len(primeiro_sequencial))) + primeiro_sequencial
                    self.hostname = self.prefixo + self.sequencial                        
                    logging.warning("hostname construído: " + self.hostname)
                    return True

                else:
                    logging.warning("não conseguiu inserir prefixo para alocação, aguardando 10s")
                    tempo += 1
                    time.sleep(10)

            return False

        except Exception:
            logging.warning("erro: " + traceback.format_exc())

        finally:
            self.removePrefixoEmConstrucao(reserva)
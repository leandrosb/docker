# -*- encoding: utf-8 -*-


from flask_api import FlaskAPI, status, exceptions, request
from flask import g,current_app
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.ext.automap import automap_base
from sqlalchemy.orm import Session,scoped_session,sessionmaker
from sqlalchemy import create_engine
from flask_sqlalchemy_session import flask_scoped_session
import pymysql as MySQLdb
from flask_login import LoginManager, login_user, UserMixin, current_user
from flask_bootstrap import Bootstrap
from flask_migrate import Migrate
import logging,time
from flask.cli import with_appcontext
import subprocess
from concurrent.futures import ProcessPoolExecutor,ThreadPoolExecutor
from threading import Thread
import traceback
from config import app_config

app = FlaskAPI(__name__)
Base = automap_base()
db = SQLAlchemy()

def create_app(config_name):
    app = FlaskAPI(__name__, instance_relative_config=True)
    app.config.from_object(app_config[config_name])
    app.config.from_pyfile('config.py')
    engine = create_engine(app.config['SQLALCHEMY_DATABASE_URI'],isolation_level="READ UNCOMMITTED")
    # reflect the tables
    Base.prepare(engine, reflect=True)
    Bootstrap(app)
    db = SQLAlchemy(app)
    db.Model.metadata.reflect(db.engine)
    migrate = Migrate(app, db)
    from app import models

    '''
    login_manager = LoginManager()
    login_manager.init_app(app)
    login_manager.login_message = "Acesso permitido apenas após login."
    login_manager.login_view = "auth.login"
    
    from .models import Usuario

    # Set up user_loader
    @login_manager.user_loader
    def load_user(user_id):
        return Usuario.query.get(int(user_id))
    '''
    from .context import context as context_blueprint
    app.register_blueprint(context_blueprint)
    app.config['BOOTSTRAP_SERVE_LOCAL'] = True
    return app


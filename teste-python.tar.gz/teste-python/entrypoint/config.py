

SECRET_KEY = '$h3_pr0c3ss4m3nt0_h3'


SQLALCHEMY_DATABASE_URI = 'mysql://ahe_hostname:ahe_hostname@172.17.188.63/ahe_hostname'


LDAP_PROVIDER_URL = 'ldap://ldp0pb1.bb.com.br:389/'


LDAP_URI_LOGIN = 'ou=usuarios,ou=acesso,o=BB,C=BR'


LDAP_PROTOCOL_VERSION = 3


WTF_CSRF_SECRET_KEY = '$h3_pr0c3ss4m3nt0_h3'


SQL_DATABASE = 'ahe_hostname'


LDAP_HOST = 'ldp0pb1.bb.com.br'


LDAP_PORT = 389


LDAP_SCHEMA = 'ldap'


LDAP_BASE_DN = 'ou=usuarios,ou=acesso,o=BB,C=BR'


LDAP_USERNAME = 'uid=lnx01usr,ou=bind,ou=usuarios,ou=acesso,O=BB,C=BR'


LDAP_PASSWORD = '42w666fu'


